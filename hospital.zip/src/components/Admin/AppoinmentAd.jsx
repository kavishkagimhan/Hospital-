import React from 'react'

const AppoinmentAd = () => {
  return (
    <div>AppoinmentAd</div>
  )
}

export default AppoinmentAd