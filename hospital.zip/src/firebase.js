
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore"
import { getAuth} from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCew_IPkpwPNjtlXhkz0jRVMA9eyvg0Azk",
  authDomain: "hospital-booking-system-9d2b8.firebaseapp.com",
  projectId: "hospital-booking-system-9d2b8",
  storageBucket: "hospital-booking-system-9d2b8.appspot.com",
  messagingSenderId: "566174434284",
  appId: "1:566174434284:web:8d1df0d33a5d91c42976c9"
};


const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);